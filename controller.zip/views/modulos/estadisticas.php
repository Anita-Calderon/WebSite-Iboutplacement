<section class="mb-5 mt-5">
    <div class="container ">
    <h1 class="text-center py-2" style="font-size:2.34rem; ">
            <b style="color:black;"> ESTADÍSTICAS 2020 - 2021</b>
            </h1>
        <div class="row homeport ">

            <div class="col-md-6 col-sm-6 block-item py-3">
                <div class="card ">
                    <figure class="effect-block m-0 p-0">
                        <a href="views/images/estadistica1.png" class="fancybox" data-fancybox="gallery1">
                            <img src="views/images/estadistica1.png" alt="img" class="img-responsive" />
                        </a>
                    </figure>
                </div>
            </div>

            <div class="col-md-6 col-sm-6 block-item py-3">
                <div class="card ">
                    <figure class="effect-block m-0 p-0">
                        <a href="views/images/estadistica2.png" class="fancybox" data-fancybox="gallery1">
                            <img src="views/images/estadistica2.png" alt="img" class="img-responsive" />
                        </a>
                    </figure>
                </div>
            </div>

            <div class="col-md-6 col-sm-6 block-item py-3">
                <div class="card ">
                    <figure class="effect-block m-0 p-0">
                        <a href="views/images/estadistica3.png" class="fancybox" data-fancybox="gallery1">
                            <img src="views/images/estadistica3.png" alt="img" class="img-responsive" />
                        </a>
                    </figure>
                </div>
            </div>

            <div class="col-md-6 col-sm-6 block-item py-3">
                <div class="card ">
                    <figure class="effect-block m-0 p-0">
                        <a href="views/images/estadistica4.png" class="fancybox" data-fancybox="gallery1">
                            <img src="views/images/estadistica4.png" alt="img" class="img-responsive" />
                        </a>
                    </figure>
                </div>
            </div>

            <div class="col-md-6 col-sm-6 block-item py-3">
                <div class="card ">
                    <figure class="effect-block m-0 p-0">
                        <a href="views/images/estadistica5.png" class="fancybox" data-fancybox="gallery1">
                            <img src="views/images/estadistica5.png" alt="img" class="img-responsive" />
                        </a>
                    </figure>
                </div>
            </div>

            <div class="col-md-6 col-sm-6 block-item py-3">
                <div class="card ">
                    <figure class="effect-block m-0 p-0">
                        <a href="views/images/estadistica6.png" class="fancybox" data-fancybox="gallery1">
                            <img src="views/images/estadistica6.png" alt="img" class="img-responsive" />
                        </a>
                    </figure>
                </div>
            </div>

        </div>
    </div>

    </div>
</section>

<section id="servicios">
    <?php include 'servicios.php';?>
</section>