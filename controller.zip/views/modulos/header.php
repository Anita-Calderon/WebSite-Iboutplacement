<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords"
        content="personalidad profesional, sociedad civil profesional personalidad juridica, personalidad del profesional de enfermeria, personalidad del profesional y su dignidad, la personalidad profesional, personalidad y carrera profesional , Programa de reinserción laboral , Preguntas key para entrevista de empleo , Entrevistas de empleo , cómo hacer una buena entrevista de job , lo que te motiva en la entrevista de job , recolocación professional , ejemplos de las debilidades de un professional , cazatalentos de reemplazo professional , reemplazo professional para ingenieros , reemplazo professional que es , entrevista por competencias , cómo prepararse para una entrevista , competencia actitudinal , entrevista de job tips , como presentarse en una entrevista personal , cómo presentarse a una entrevista de job , outplacement , outplacement Perú , humano capital empleos , outplacement chile , IBVirtual , Outplacement , Coaching  , Contact personas , Contact Empresas , Contact Us , Nuestros Services , E-learning , Primer job , Página WEB , Linkedin , Ebook , Estadísticas , Coach peruanos , Coaching en Perú , Coaching lima , Outplacement Perú , Que es outplacement , Coach personal lima , Recolocación laboral , Talleres ib , Empresas peruanas que aplican outplacement , Empresas outplacement , Tipos de outplacement , Outplacement objetivos , Outplacement 2020 , Outplacement 2021 , Outplacement personas , Outplacement personal , Empresas peruanas que utilizan el coaching , coaching empresarial Perú">
    <meta name="description" content="IBOutplacement, la solución">
    <title>IBOutplacement</title>
    <link rel="shortcut icon" href="views/images/favicono.png">

    <!--ESTILOS-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <link rel="stylesheet" href="views/css/bootstrap.min.css">
    <link rel="stylesheet" href="views/css/modal-video.min.css">
    <link rel="stylesheet" href="views/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/glider-js@1.7.3/glider.min.css">
    <link rel="stylesheet" href="views/css/estilos.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Oswald&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css"
        href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.css">


</head>

<body>

    <?php include_once "menu.php"?>

    