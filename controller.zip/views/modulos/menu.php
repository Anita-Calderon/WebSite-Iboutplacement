<div class="sticky-top container-fluid p-0 m-0">
    <nav class="navegaciones">
        <input type="checkbox" id="check">
        <label for="check" class="checkbtn">
            <i class="fas fa-bars"></i>
        </label>
        <a href="inicio" class="enlace">
            <img src="views/images/logo_empresa.png" alt="" class="logo">
        </a>
        <ul>
            <li><a class="active" href="inicio">INICIO</a>
            <li><a href="inicio#servicios">SERVICIOS</a></li>
            <li><a href="PreguntasFrecuentes">PREGUNTAS</a></li>
            <li><a href="https://outplacementt.blogspot.com/">BLOG</a></li>
            <li><a class="contact" href="inicio#Contactos">CONTÁCTANOS </a></li>
            <li><a href="estadisticas">ESTADÍSTICAS</a></li>
            <li><a href="https://corpibgroup.com/ibmaximiz/">IBMAXIMIZA</a></li>
            <li><a href="https://ibjobcoach.com/" >IBJOBCOACH</a></li>
        </ul>
    </nav>
</div>
