<footer class="footer-tipo">
    <div class="container">
        <div class="row">
            <div class="footer-col">

                <a class="menus" href="PreguntasFrecuentes">Preguntas Frecuentes</a>
                <a class="menus" href="https://outplacementt.blogspot.com">Blog</a>
                <a class="menus" href="estadisticas">Estadísticas</a>

            </div>
            <div class="footer-col ">

                <a class="menus" href="inicio">Inicio</a>
                <a class="menus" href="inicio#servicios">Servicios</a>
                <a class="menus" href="inicio#Contactos">Contáctanos</a>
                <a class="menus" href="https://ibjobcoach.com/">IBjobcoach</a>
            </div>
            <div class="footer-col">

                <span> IBCORP SAC RUC 20601399882</span>

                <p> cm.outplacement.coaching@corpibgroup.com</p>

                <p > Central Telefónica: (511) 748 5112</p>

                <p>Oficina Central: Av. Circunvalación Club Golf los Incas, Torre 3, Nro 208, Oficina 602B , Urb. Club Golf los Incas , Santiago de Surco, Lima, Perú</p>
            </div>
            <div class="footer-col">
                <div class="sociales">
                    <a style="background-color: #3c70a4; color: white;" href="https://www.facebook.com/IBOutplacementOficial/"><i class="fab fa-facebook"></i></a>
                    <a style="background-color: #33BAFF; color: white;" href="https://twitter.com/ib_outplacement"><i class="fab fa-twitter "></i></a>
                    <a style="background-color: #C8062F; color: white;" href="https://www.youtube.com/channel/UC9NkcDwe6-P37cHXkn1XBcA/"><i class="fab fa-youtube"></i></a>
                    <a style="background: radial-gradient(circle at 30% 107%, #fdf497 0%, #fdf497 5%, #fd5949 45%,#d6249f 60%,#285AEB 90%); box-shadow: 0px 3px 10px rgba(0,0,0,.25); color: white;" href="https://www.instagram.com/iboutplacement/"><i class="fab fa-instagram"></i></a>
                    <a style="background-color: #06A0C8; color: white;" href="https://www.linkedin.com/company/iboutplacement"><i class="fab fa-linkedin "></i></a>
                </div>
            </div>
        </div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/glider-js@1.7.3/glider.min.js"></script>
<script src="views/js/jquery-3.5.1.min.js"></script>
<script src="views/js/ajax.js"></script>
<script src="views/js/efectos.js"></script>
<script src="views/js/bootstrap.bundle.js"></script>
<script src="views/js/bootstrap.min.js"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js"></script>
<script src="views/js/jquery-modal-video.min.js"></script>
<script src="views/js/wow.min.js"></script>
<script src="views/js/popper.min.js"></script>
<script src="views/js/popup.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.0.943/pdf.min.js"></script>

<script>
    new WOW().init();
</script>
</body>
<script>
    /*   $(document).ready(function() {
        setTimeout(function() {
            $('#myModal').modal('show')
        }, 2000);
    });*/
</script>

</html>