<?php

class ControllerPlantilla{
    //método para dibujar la plantilla
    static public function ctrPlantilla(){
        include "views/plantilla.php";
    }
}
